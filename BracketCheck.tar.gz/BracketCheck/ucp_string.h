#ifndef STRING
#define STRING

void ucp_strcpy( char*, char* );
void copyBefore( char*, char*, int );
void copyAfter( char*, char*, int );
int isAlpha( char );
int ucp_strcmp( char[], char[] );
int ucp_strlen( char* );

#endif
