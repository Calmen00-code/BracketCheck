#ifndef MAIN
#define MAIN

#define LEN 500
#define FALSE 0
#define TRUE !FALSE

void freeContent( char**, int );

#endif
