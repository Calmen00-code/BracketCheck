#ifndef FILE_H
#define FILE_H

#include "main.h"

char** read( char *, int * );
int getFileSize( FILE* );

#endif
