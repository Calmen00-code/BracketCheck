#ifndef DISPLAY
#define DISPLAY

void display( char**, int );
int writeColorText( char*, char*, char*, char, char* );
void printErrorMsg( char, char* );
void printBefore( char**, int );
void printAfter( char**, int, int );

#endif
