#include<stdio.h>

int main(int argc, char * argv[])
{
    printf("this is a good example\n");
    return 0;
}

void print()
{
    printf("second");
}
