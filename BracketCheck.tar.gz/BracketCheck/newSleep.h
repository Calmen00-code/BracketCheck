#ifndef NEWSLEEP_H
#define NEWSLEEP_H

#include <time.h>

void newSleep(float sec);

#endif
